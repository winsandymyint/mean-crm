/**************************************************************************
 * Slider Revolution jQuery Visual Editor Extension
 * @version: 5.1 (20.10.2015)
 * @author ThemePunch
**************************************************************************/

This is the extension file for the Visual Editor Add On of Slider Revolution.

The visual-editor-extension.zip will only work in cooperation with the Slider Revolution jQuery Visual Editor Product which is available in our Portfolio at http://codecanyon.net/user/themepunch/portfolio 

Your Team @ThemePunch
